package Methods;

import java.util.List;
import java.util.Scanner;
import Domain.Person;
public class Process {
        public static void showMenu(){
            System.out.println("""
        *** Choose an option ***
        [1] add people
        [2] list people
        [3] salir
        """);
        }

        public static boolean executeOptions(Scanner consola, List<Person> peopleList){
            int option = Integer.parseInt(consola.nextLine());
            boolean exit = false;

            switch(option){
                case 1:System.out.println("Type the name");
                    String name = consola.nextLine();
                    Person objectPerson = new Person(name);
                    peopleList.add(objectPerson);
                case 2:
                    peopleList.forEach(System.out::println);
                    //System.out.println(name);

            }
            return exit;
        }


}


