package Presentation;
import Domain.Person;
import Methods.Process;

import java.util.List;import java.util.ArrayList;
import java.util.Scanner;
public class Presentation {
        public static void main (String[] args){
            Scanner consola = new Scanner(System.in);

            List<Person> peopleList = new ArrayList<>();
            boolean exit = false;
            while (!exit){

                Process.showMenu();

                Process.executeOptions(consola,peopleList);

            }
        }


//         Person objectPeople = new Person("Carlos");
//         objectPeople.getName();
//         objectPeople.setName("Juan");
//            System.out.println();
// }
}